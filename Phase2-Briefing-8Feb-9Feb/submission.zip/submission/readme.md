TCS Challenge. Team Entry Number :   04489267
=================
# Description
This scripts should have past 15 data points as input to predict the following 5 days ftse close data.
Hence, for predicting data between 2024-03-09 to 2024-03-15, it requires the data between
2024-02-19 and 2014-03-08, the data should be in the exact the same format, index name
and order as the file provided for training.

# Test Script Usage
1. Set up the environment
    ```
    pip install -r requirements.txt
    ```
2. Run test script for real inference
    ```
    python predict_script.py -i INPUT_DATA_PATH -w MODEL_WEIGHTS_PATH -t
    ```
By default, \
`INPUT_DATA_PATH='/data/Forecasting-FTSE100-Index-Dataset-v1.1.xlsxsubmission'` \
`MODEL_WEIGHTS_PATH='models/lstm_nq_3_input_3_hid_100_in_15_out_5_vqc_00_398'`\
Without flag `-t`, the script will run a dummy inference.\
For more information, run `python predict_script.py -h`

# Details
## Architecture
To predict the future stock price, we use an architecture of Quantum Long Short-Term Memory (QLSTM) model as presented by Chen _et al_., [2020](https://arxiv.org/abs/2009.01783). In their paper, the gates in conventional LSTM are replaced by a variational quantum circuits (VQC) to achieve a hybrid quantum-classical model. The Architecture of QLSTM and the VQC setup used in this experiment are shown in figures below.

<img src="figures/qlsm_fig.png" alt="drawing" style="width:400px;"/>\
**Fig. 1** The QLSTM architecture.

<img src="figures/vqc_fig.png" alt="drawing" style="width:300px;"/>\
**Fig. 2** The VQC setup.

## Data
We use features of FTSE open, close, and volume in last 15 days as input data to predict the next 5 days close stock price. 

## Experiment setup
The hidden dimension of the QLSTM is set to be 100.
For each VQC, we use 3 qubits, which is empirically shown to be optimal for this task. 
The model is trained with `Adam` optimizer for 400 epochs.