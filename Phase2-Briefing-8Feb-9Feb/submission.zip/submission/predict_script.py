import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from models.qlstm import script_lstm
import sys
from datetime import date, timedelta
import argparse

def daterange(pred_start_date, pred_end_date):
    def str2int(date_str, separator='-'):
        return list(map(int, date_str.split(separator)))
    start_date = date(*str2int(pred_start_date))
    end_date = date(*str2int(pred_end_date))
    dates = []
    for n in range(int((end_date - start_date).days)+1):
        dates.append(start_date + timedelta(n))
    return dates

def inference(args):
    # change the input file to updated version which include the past 15 days
    if args.inference_task:
        input_start_date = '2024-02-19'
        input_end_date = '2024-03-08'
        pred_start_date = '2024-03-11'
        pred_end_date = '2024-03-15'
    else:
        input_start_date = '2023-08-07'
        input_end_date = '2023-08-25'
        pred_start_date = '2023-08-28'
        pred_end_date = '2023-09-01'

    input_len = 15
    ftse_max = 8014.3
    ftse_min = 4944.4
    volume_max = 3761301200.0
    volume_min = 8378200.0
    raw_frame_ftse = pd.read_excel(args.input_data_file, '^FTSE', index_col='Date', parse_dates=True)
    input_data = raw_frame_ftse[input_start_date : input_end_date]
    if len(input_data) != input_len:
        print('input data error')
        sys.exit()
    np_ftse = input_data.to_numpy()
    # 3 features, ftse open, close, volume
    feature_data = np.zeros((input_len,3), dtype='float32') 
    feature_data[:,0] = (np_ftse[:,3] - ftse_min) / (ftse_max - ftse_min)
    feature_data[:,1] = (np_ftse[:,0] - ftse_min) / (ftse_max - ftse_min)
    feature_data[:,2] = (np_ftse[:,5] - volume_min) / (volume_max - volume_min)
    if feature_data.min() < 0 :
        print('normalization error')
        sys.exit()
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    input_dim = 3
    hidden_dim = 100
    n_out = 5
    n_qubits = 3
    class LSTMModel(nn.Module):
        def __init__(self, input_dim, hidden_dim, num_layers, tagset_size, VQC_nlayers, VQC_nqubits):
            super(LSTMModel, self).__init__()
            self.hidden_dim = hidden_dim
            self.num_layers = num_layers
            self.lstm = script_lstm(input_dim, hidden_dim, num_layers, VQC_nlayers, VQC_nqubits, batch_first=False)
            self.fc = nn.Linear(hidden_dim, tagset_size)
        def forward(self, x):
            h0 = torch.zeros(self.num_layers, x.size(1), self.hidden_dim).requires_grad_()
            c0 = torch.zeros(self.num_layers, x.size(1), self.hidden_dim).requires_grad_()
            out, (_, _) = self.lstm(x, (h0.detach(), c0.detach()))
            out = self.fc(out[-1, :, :]) #only predict one sequence
            return out
    model = LSTMModel(input_dim=input_dim, hidden_dim=hidden_dim, num_layers=2, tagset_size=n_out, VQC_nlayers=1, VQC_nqubits=n_qubits)
    if torch.cuda.is_available():
        model.load_state_dict(torch.load(args.weight_file))
    else:
        model.load_state_dict(torch.load(args.weight_file, map_location=torch.device('cpu') ))
    model.to(device)
    model.eval()
    feature_data_exp = np.expand_dims(feature_data, axis=1)
    x_in = torch.tensor(feature_data_exp, dtype=torch.float32)
    y_pred = model(x_in.to(device=device)).detach().cpu().numpy()
    # this is the final prediction:
    rescaled_pred = y_pred[0] * (ftse_max-ftse_min) + ftse_min
    dates = daterange(pred_start_date, pred_end_date)
    for i in range(len(dates)):
        print(f'FTSE CLOSE for {dates[i]}: {rescaled_pred[i]}')
    # You can calculate the MSE / MAE (normalized / unnormalized) here

if __name__ == '__main__':
    parser = argparse.ArgumentParser(
                    prog='QLSTM_TCS',
                    description='''
                                This scripts should have past 15 data points as input to predict the following 5 days ftse close data.
                                Hence, for predicting data between 2024-03-09 to 2024-03-15, it requires the data between
                                2024-02-19 and 2014-03-08, the data should be in the exact the same format, index name
                                and order as the file provided for training.
                                ''')
    parser.add_argument('-i', '--input_data_file', 
                        type=str, 
                        default='data/Forecasting-FTSE100-Index-Dataset-v1.1.xlsx',
                        help='The path of input data'
                        )
    parser.add_argument('-w', '--weight_file',
                        type=str,
                        default='models/lstm_nq_3_input_3_hid_100_in_15_out_5_vqc_00_398',
                        help='The paht of model weights'
                        )
    parser.add_argument('-t', '--inference_task',
                        action=argparse.BooleanOptionalAction,
                        default=False,
                        help='Add this flag when predicting real data'
                        )
    args = parser.parse_args()
    inference(args)