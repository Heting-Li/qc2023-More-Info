import numbers
import warnings
from collections import namedtuple
from typing import List, Tuple

import torch
import torch.jit as jit
import torch.nn as nn
from torch import Tensor
from torch.nn import Parameter
from .VQC import VQC_class

"""
Some helper classes for writing custom TorchScript LSTMs.

Goals:
- Classes are easy to read, use, and extend
- Performance of custom LSTMs approach fused-kernel-levels of speed.

A few notes about features we could add to clean up the below code:
- Support enumerate with nn.ModuleList:
  https://github.com/pytorch/pytorch/issues/14471
- Support enumerate/zip with lists:
  https://github.com/pytorch/pytorch/issues/15952
- Support overriding of class methods:
  https://github.com/pytorch/pytorch/issues/10733
- Support passing around user-defined namedtuple types for readability
- Support slicing w/ range. It enables reversing lists easily.
  https://github.com/pytorch/pytorch/issues/10774
- Multiline type annotations. List[List[Tuple[Tensor,Tensor]]] is verbose
  https://github.com/pytorch/pytorch/pull/14922
"""


def script_lstm(
    input_size,
    hidden_size,
    num_layers,
    VQC_nlayers,
    VQC_nqubits,
    bias=True,
    batch_first=False,
):
    """Returns a ScriptModule that mimics a PyTorch native LSTM."""

    # The following are not implemented.
    assert bias
    assert not batch_first

    dirs = 1
    return StackedLSTM(
        num_layers,
        LSTMLayer,
        first_layer_args=[LSTMCell, input_size, hidden_size, VQC_nlayers, VQC_nqubits],
        other_layer_args=[LSTMCell, hidden_size * dirs, hidden_size, VQC_nlayers, VQC_nqubits],
    )


LSTMState = namedtuple("LSTMState", ["hx", "cx"])

class LSTMCell(nn.Module):
    def __init__(self, input_size, hidden_size, VQC_nlayers, VQC_nqubits):
        super(LSTMCell, self).__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.VQC1 = VQC_class(input_size+hidden_size, hidden_size, VQC_nlayers, VQC_nqubits)
        self.VQC2 = VQC_class(input_size+hidden_size, hidden_size, VQC_nlayers, VQC_nqubits)
        self.VQC3 = VQC_class(input_size+hidden_size, hidden_size, VQC_nlayers, VQC_nqubits)
        self.VQC4 = VQC_class(input_size+hidden_size, hidden_size, VQC_nlayers, VQC_nqubits)
        self.VQC5 = VQC_class(hidden_size, hidden_size, VQC_nlayers, VQC_nqubits)
        
    def forward(self, input, state):
        # type: (Tensor, Tuple[Tensor, Tensor]) -> Tuple[Tensor, Tuple[Tensor, Tensor]]
        hx, cx = state
        ingate     = self.VQC1(torch.cat([input, hx.to(input.device)], dim=1))
        forgetgate = self.VQC2(torch.cat([input, hx.to(input.device)], dim=1))
        cellgate   = self.VQC3(torch.cat([input, hx.to(input.device)], dim=1))
        outgate    = self.VQC4(torch.cat([input, hx.to(input.device)], dim=1))

        ingate = torch.sigmoid(ingate)
        forgetgate = torch.sigmoid(forgetgate)
        cellgate = torch.tanh(cellgate)
        outgate = torch.sigmoid(outgate)

        cy = (forgetgate * cx.to(input.device)) + (ingate * cellgate)
        # hy = outgate * torch.tanh(cy)
        hy = self.VQC5(outgate * torch.tanh(cy))

        return hy, (hy, cy)

class LSTMLayer(nn.Module):
    def __init__(self, cell, *cell_args):
        super().__init__()
        self.cell = cell(*cell_args)

    def forward(
        self, input: Tensor, state: Tuple[Tensor, Tensor]
    ) -> Tuple[Tensor, Tuple[Tensor, Tensor]]:
        inputs = input.unbind(0)
        # outputs = torch.jit.annotate(List[Tensor], [])
        outputs = []
        for i in range(len(inputs)):
            out, state = self.cell(inputs[i], state)
            outputs += [out]
        return torch.stack(outputs), state

def init_stacked_lstm(num_layers, layer, first_layer_args, other_layer_args):
    layers = [layer(*first_layer_args)] + [
        layer(*other_layer_args) for _ in range(num_layers - 1)
    ]
    return nn.ModuleList(layers)


class StackedLSTM(nn.Module):
    __constants__ = ["layers"]  # Necessary for iterating through self.layers

    def __init__(self, num_layers, layer, first_layer_args, other_layer_args):
        super().__init__()
        self.layers = init_stacked_lstm(
            num_layers, layer, first_layer_args, other_layer_args
        )

    def forward(
        self, input: Tensor, states: List[Tuple[Tensor, Tensor]]
    ) -> Tuple[Tensor, List[Tuple[Tensor, Tensor]]]:
        # List[LSTMState]: One state per layer
        # output_states = jit.annotate(List[Tuple[Tensor, Tensor]], [])
        output_states = []
        output = input
        # XXX: enumerate https://github.com/pytorch/pytorch/issues/14471
        i = 0
        for rnn_layer in self.layers:
            state = states[i]
            output, out_state = rnn_layer(output, state)
            output_states += [out_state]
            i += 1
        return output, output_states


def flatten_states(states):
    states = list(zip(*states))
    assert len(states) == 2
    return [torch.stack(state) for state in states]


def double_flatten_states(states):
    # XXX: Can probably write this in a nicer way
    states = flatten_states([flatten_states(inner) for inner in states])
    return [hidden.view([-1] + list(hidden.shape[2:])) for hidden in states]